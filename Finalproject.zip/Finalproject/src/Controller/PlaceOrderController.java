/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;


import DAO.BillDAO;
import DAO.ProductDAO;
import Model.BillItem;
import Model.Product;
import UI.BillFrame;
import java.awt.Component;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JPanel;
import UI.PlaceOrderPanel;
import UI.ProductItemPanel;
import database.brotherconnection;
import java.awt.Color;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author ThinkBook
 */
public class PlaceOrderController {
    private PlaceOrderPanel take_btn_panel;
    private JPanel productContainer;
    private JScrollPane scrollPane;
    private JPanel placeorder_pane;
    private JButton all_btn;
    private AdminController adminController;
    
    private int batchSize = 12;
    private int loadedCount = 0;
    private ArrayList<Product> list = new ArrayList<>();

    private JTable place_table; 
    private JTextField Total; 
    private PlaceOrderPanel orderPanel; 
    
    private ProductDAO productDAO;
    private BillDAO billDAO;
    
    public PlaceOrderController(PlaceOrderPanel panel) {
        this.take_btn_panel = panel;
        this.productContainer = panel.getProductContainer();
        this.productContainer = panel.getProductContainer();
        this.scrollPane = panel.getScrollPane();
        this.placeorder_pane = panel.getPlaceorderpanel();
        this.all_btn = panel.getAllbutton();
        
        this.orderPanel = panel;
        this.place_table = orderPanel.getPlaceTable();
        this.Total = orderPanel.getTotalTextField();
        
        this.productDAO = new ProductDAO();
        this.billDAO = new BillDAO();
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
        
        DefaultTableCellRenderer currencyRenderer = new DefaultTableCellRenderer() {
            @Override
            public void setValue(Object value) {
                if (value instanceof Number) {
                    value = currencyFormat.format(value);
                }
                super.setValue(value);
            }
        };
    
   
        currencyRenderer.setHorizontalAlignment(javax.swing.JLabel.RIGHT);

    
        try {
            place_table.getColumnModel().getColumn(4).setCellRenderer(currencyRenderer);
            place_table.getColumnModel().getColumn(5).setCellRenderer(currencyRenderer);
        } catch (Exception e) {
            System.out.println("Error");
        }

        setupDeleteButton();
        setupResetButton();
    }
    
    public void setAdminController(AdminController adminCtrl) {
        this.adminController = adminCtrl;
    }
    
    public void click_default(){
        List<Product> prods = getProductsByCategory("All");
        highlightButtonDefault();
        showProducts(prods);
    }
    
    public List<JButton> getButtonsInPanel(JPanel panel) {
        List<JButton> list = new ArrayList<>();
        for (Component comp : panel.getComponents()) {
            if (comp instanceof JButton) {
                list.add((JButton) comp);
            }
        }
        return list;
    }
    
    
    
    public void registerButtonEvents() {
        List<JButton> btns = getButtonsInPanel(take_btn_panel.getButtonPanel());

        for (JButton b : btns) {
            b.addActionListener(e -> {
                highlightSelectedButton(b, btns);
                List<Product> prods = getProductsByCategory(b.getText());
                showProducts(prods);
            });
        }
    }

    
    private void highlightButtonDefault(){
        List<JButton> btns = getButtonsInPanel(take_btn_panel.getButtonPanel());
        for (JButton b : btns) {
            if (b == all_btn) {
                b.setBackground(new Color(204, 0, 0));
                b.setForeground(new Color(204,204,204));
            } else {
                b.setBackground(new Color(255, 51, 51));
                b.setForeground(Color.WHITE);
            }
        }
    }
    
    private void highlightSelectedButton(JButton selected, List<JButton> all) {
        
        for (JButton b : all) {
            if (b == selected) {
                b.setBackground(new Color(204, 0, 0));
                b.setForeground(new Color(204,204,204));
            } else {
                b.setBackground(new Color(255, 51, 51));
                b.setForeground(new Color(255,255,255));
            }
        }
    }
    
    public List<Product> getProductsByCategory(String category) {
    try {
        return productDAO.getProductsByCategory(category);
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        return new ArrayList<>();
    }
}
        
    public void showProducts() {
    productContainer.removeAll();
    loadedCount = 0;

    try {
        List<Product> products = productDAO.getAllProducts();

        for (Product product : products) {
            ProductItemPanel productPanel = new ProductItemPanel(product);
            productPanel.setAdminController(this);
            productContainer.add(productPanel.getitems_panel());
        }

    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
    }

    productContainer.revalidate();
    productContainer.repaint();
}

    
    public void showProducts(List<Product> products) {
        productContainer.removeAll();

        for (Product p : products) {
            ProductItemPanel item = new ProductItemPanel(p);
            item.setAdminController(this);
            productContainer.add(item.getitems_panel());
        }

        productContainer.revalidate();
        productContainer.repaint();
    }
    
    public void loadMoreProducts(JPanel productContainer) {
        int end = Math.min(loadedCount + batchSize, list.size());

        for (int i = loadedCount; i < end; i++) {
            ProductItemPanel item = new ProductItemPanel(list.get(i));
            item.setAdminController(this);
            productContainer.add(item);
        }

        loadedCount = end;
        productContainer.revalidate();
        productContainer.repaint();
    }

    
    public void enableAutoLoad() {
        scrollPane.getVerticalScrollBar().addAdjustmentListener(e -> {
            JScrollBar bar = scrollPane.getVerticalScrollBar();
            int extent = bar.getModel().getExtent();
            int value = bar.getValue();
            int max = bar.getMaximum();

            if (value + extent >= max - 50) {
                loadMoreProducts(productContainer);
            }
        });
    }
    
    public void addProductToTable(Product productUI, int quantity) {
        System.out.print("add product: " + productUI.getName());

        try {
            Product dbProduct = productDAO.getProductById(productUI.getId());
            if (dbProduct == null) {
                JOptionPane.showMessageDialog(null, "Product not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int stock = dbProduct.getStock();
            DefaultTableModel model = (DefaultTableModel) place_table.getModel();

            int currentQtyInCart = 0;

            for (int i = 0; i < model.getRowCount(); i++) {
                int idInTable = Integer.parseInt(model.getValueAt(i, 0).toString());
                if (idInTable == productUI.getId()) {
                    currentQtyInCart += Integer.parseInt(model.getValueAt(i, 3).toString());
                }
            }

            if (currentQtyInCart + quantity > stock) {
                 JOptionPane.showMessageDialog(null, 
                    "Not enough stock!\n" +
                    "Total in stock: " + stock + "\n" +
                    "You already have: " + currentQtyInCart + " in cart.\n",
                    "Stock Error", JOptionPane.WARNING_MESSAGE);
                return; 
            }

            String variant = productUI.getVariantInfo();
            String displayName = dbProduct.getName();

            if (variant != null && !variant.isEmpty()) {
                displayName = displayName + " (" + variant + ")";
            }

            String type = dbProduct.getType();
            double price = dbProduct.getPrice();
            boolean found = false;

            for (int i = 0; i < model.getRowCount(); i++) {
                int currentId = Integer.parseInt(model.getValueAt(i, 0).toString());
                String currentName = model.getValueAt(i, 1).toString();

                if (currentId == productUI.getId() && currentName.equals(displayName)) {
                    int currentQty = Integer.parseInt(model.getValueAt(i, 3).toString());
                    int newQty = currentQty + quantity;

                    double newSubtotal = newQty * price;
                    model.setValueAt(newQty, i, 3);
                    model.setValueAt(newSubtotal, i, 5);
                    found = true;
                    break;
                }
            }

            if (!found) {
                double subtotal = price * quantity;
                model.addRow(new Object[]{
                    productUI.getId(),
                    displayName,
                    type,
                    quantity,
                    price,
                    subtotal
                });
            }

            updateTotal();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding product: " + e.getMessage());
        }
    }

    
    private void updateTotal() {
        DefaultTableModel model = (DefaultTableModel) place_table.getModel();
        double total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            Object obj = model.getValueAt(i, 5); 
            double subtotal = obj instanceof Number ? ((Number) obj).doubleValue() : 0;
            total += subtotal;
        }

        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
        Total.setText(currencyFormat.format(total));
    }

    private void setupDeleteButton() {
        if (orderPanel != null && orderPanel.getDeleteButton() != null) {
            orderPanel.getDeleteButton().addActionListener(e -> deleteSelectedRow());
        }
    }
    
        
        private void setupResetButton() {
        if (orderPanel != null && orderPanel.getResetButton() != null) {
            orderPanel.getResetButton().addActionListener(e -> ResetTable());
        }
    }

    
    private void deleteSelectedRow() {
        JTable placeTable = orderPanel.getPlaceTable();
        DefaultTableModel model = (DefaultTableModel) placeTable.getModel();
        int selectedRow = placeTable.getSelectedRow();

        if (selectedRow >= 0) {
            model.removeRow(selectedRow);   
            updateTotal();                  
        }     
    }
    
    private void ResetTable(){
        JTable placeTable = orderPanel.getPlaceTable();
        DefaultTableModel model = (DefaultTableModel) placeTable.getModel();
        
        model.setRowCount(0); 
        updateTotal();  
    }

    
    public void handleOrderAndPrint() {
        DefaultTableModel model = (DefaultTableModel) place_table.getModel();

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(null, "No items in the order!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String cashierName = "Admin";
        int cashierId = 0;
        Model.User currentUser = Model.Session.getCurrentUser();
        if (currentUser != null) {
            cashierName = currentUser.getUsername(); 
            cashierId = currentUser.getId();
        }

        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        String formattedDate = now.format(formatter);

        StringBuilder receipt = new StringBuilder();
        receipt.append("************ BROTHER CHICKEN ***********\n");
        receipt.append("Add: Dorm 1 VGU, HCMC\n");
        receipt.append("----------------------------------------\n");

        receipt.append("Date:    " + formattedDate + "\n");
        receipt.append("Cashier: " + cashierId + "--" + cashierName + "\n"); 

        receipt.append("----------------------------------------\n");
        receipt.append(String.format("%-20s %-5s %13s\n", "Item", "Qty", "Price"));
        receipt.append("----------------------------------------\n");

        double total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {
            String item = model.getValueAt(i, 1).toString();  
            int qty = (int) model.getValueAt(i, 3);            
            double subtotal = (double) model.getValueAt(i, 5); 

            if (item.length() > 20) {
                receipt.append(String.format("%-20s %-5d %,13.0f\n", item.substring(0, 20), qty, subtotal));
                receipt.append(String.format("  %s\n", item.substring(20)));
            } else {
                receipt.append(String.format("%-20s %-5d %,13.0f\n", item, qty, subtotal));
            }

            total += subtotal;
        }

        receipt.append("----------------------------------------\n");
        receipt.append(String.format("TOTAL: %,.0f VND\n", total));
        receipt.append("----------------------------------------\n");
        receipt.append("      THANK YOU & SEE YOU AGAIN!      \n");
        receipt.append("****************************************\n");

        new BillFrame(receipt.toString(), orderPanel) {{
            setLocationRelativeTo(null);
            setDefaultCloseOperation(javax.swing.JFrame.DISPOSE_ON_CLOSE);
            setVisible(true);
        }};
    }

    public void saveBillToDatabase(DefaultTableModel model, double total) {
        Connection conn = null;

        try {
            java.util.List<BillItem> items = new java.util.ArrayList<>();
            for (int i = 0; i < model.getRowCount(); i++) {
                int productId = Integer.parseInt(model.getValueAt(i, 0).toString());
                String productName = model.getValueAt(i, 1).toString();
                int qty = Integer.parseInt(model.getValueAt(i, 3).toString());
                double subtotal = Double.parseDouble(model.getValueAt(i, 5).toString());

                items.add(new BillItem(0, productId, productName, qty, subtotal));
            }

            int userId = 1; 

            Model.User currentUser = Model.Session.getCurrentUser();
            if (currentUser != null) {
                userId = currentUser.getId(); 
            } else {
                System.out.println("Warning: No user logged in. Using default ID = 1");
            }

            conn = brotherconnection.getConnection();
            conn.setAutoCommit(false); 

            System.out.println("DEBUG: Dang luu hoa don voi Staff ID = " + userId);
            int billId = billDAO.insertBill(total, userId); 

            if (billId == 0) {
                throw new SQLException("Failed to create bill (ID returned 0). Check BillDAO.");
            }

            billDAO.insertBillItems(conn, billId, items);
            billDAO.updateStocksAndStatus(conn, items);

            conn.commit(); 

            JOptionPane.showMessageDialog(null, "Bill saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ignored) {}
            }
            e.printStackTrace(); 
            JOptionPane.showMessageDialog(null, "Error saving bill: " + e.getMessage());
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (SQLException ignored) {}
            }
        }

        model.setRowCount(0);
        updateTotal();

        if (this.adminController != null) {
            this.adminController.loadProductsFromDatabase();
        }
        click_default();
    }
}

    

