/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import javax.swing.JTable;
import DAO.BillDAO;
import DAO.BillItemDAO;
import Model.Bill;
import Model.BillItem;
import UI.ViewBillPanel;
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
/**
 *
 * @author ThinkBook
 */
public class ViewBillController {
    private ViewBillPanel view;
    private BillDAO billDAO;
    private BillItemDAO billItemDAO;
    
    public ViewBillController(ViewBillPanel view){
        this.view = view;
        this.billDAO = new BillDAO();
        this.billItemDAO = new BillItemDAO();
        
        JTable table = view.getBillTable();
        NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        DefaultTableCellRenderer currencyRenderer = new DefaultTableCellRenderer() {
            @Override
            public void setValue(Object value) {
                if (value instanceof Number) {
                    value = currencyFormat.format(value);
                }
                super.setValue(value);
            }
        };
        currencyRenderer.setHorizontalAlignment(javax.swing.JLabel.RIGHT);

        
        try {
            table.getColumnModel().getColumn(3).setCellRenderer(currencyRenderer);
        } catch (Exception e) {
            System.out.println("no row for renderer");
        }
        // ---------------------------------------------

        
        loadBillTable();
        addRowClickListener();
    }
    
    
    private void loadBillTable(){
        JTable table = view.getBillTable();
        
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);
        
        BillDAO dao = new BillDAO();
        List<Bill> bills = dao.getAllBills();
        
        for (Bill b : bills) {
            java.sql.Timestamp ts = b.getDate();
            String date = "";
            String time = "";

            if (ts != null) {
                date = ts.toLocalDateTime().toLocalDate().toString();
                time = ts.toLocalDateTime().toLocalTime().toString();
            }

           
            model.addRow(new Object[]{
                b.getId(),      
                date,         
                time,           
                b.getTotal()    
            });
        }
        
    }
    
    private void addRowClickListener() {
        view.getBillTable().addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showBillItems(); 
            }
        });
    }
    
    private void showBillItems() {
        JTable table = view.getBillTable();
        JTextArea detail = view.getDetailTextArea();

        int row = table.getSelectedRow();
        if (row < 0) return;

        int billId = (int) table.getValueAt(row, 0);
        String date = table.getValueAt(row, 1).toString();
        String time = table.getValueAt(row, 2).toString();

        String cashierName = "Unknown";
        int staffId = 0;
        String sqlUserInfo = "SELECT l.id, l.username FROM bill b JOIN login l ON b.staff_id = l.id WHERE b.bill_id = ?";
        try (java.sql.Connection conn = database.brotherconnection.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sqlUserInfo)) {
            ps.setInt(1, billId);
            java.sql.ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                staffId = rs.getInt("id");
                cashierName = rs.getString("username");
            }
        } catch (Exception e) { e.printStackTrace(); }

        BillItemDAO dao = new BillItemDAO();
        List<BillItem> items = dao.getBillItemsByBillId(billId);

        StringBuilder sb = new StringBuilder();
        sb.append("************ BROTHER CHICKEN ***********\n");
        sb.append("Add: Dorm 1 VGU, HCMC\n");
        sb.append("----------------------------------------\n");
        sb.append("Bill ID: " + billId + "\n");
        sb.append("Date:    " + date + " " + time + "\n");
        sb.append("Cashier: " + staffId + " - " + cashierName + "\n");
        sb.append("----------------------------------------\n");
        sb.append(String.format("%-20s %-5s %13s\n", "Item", "Qty", "Price"));
        sb.append("----------------------------------------\n");

        double total = 0;
        for (BillItem it : items) {
            String name = it.getProductName();
            int qty = it.getQuantity();
            double subtotal = it.getSubTotal();
            total += subtotal;

            boolean isFirstLine = true;
            while (name.length() > 20) {
                String line = name.substring(0, 20); 
                if (isFirstLine) {
                    sb.append(String.format("%-20s %-5d %,13.0f\n", line, qty, subtotal));
                    isFirstLine = false;
                } else {
                    sb.append(String.format("  %s\n", line));
                }
                name = name.substring(20); 
            }
            
            if (isFirstLine) {
                sb.append(String.format("%-20s %-5d %,13.0f\n", name, qty, subtotal));
            } else {
                sb.append(String.format("  %s\n", name));
            }
        }

        sb.append("----------------------------------------\n");
        sb.append(String.format("TOTAL: %,.0f VND\n", total));
        sb.append("----------------------------------------\n");
        sb.append("      THANK YOU & SEE YOU AGAIN!      \n");
        sb.append("****************************************\n");
        
        detail.setText(sb.toString());
        detail.setCaretPosition(0);
    }
    
    public void deleteBill() {
        JTable table = view.getBillTable();
        int selectedRow = table.getSelectedRow();
        
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(view, 
                "Please select a bill to delete!", 
                "Warning", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        
        int confirm = JOptionPane.showConfirmDialog(
            view,
            "Are you sure you want to delete this bill?\nAll items will be deleted as well.",
            "Confirm Delete",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );
        
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        
        
        int billId = (int) table.getValueAt(selectedRow, 0);
        
        try {
            billDAO.deleteBill(billId);
            
            
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.removeRow(selectedRow);
            
            
            view.getDetailTextArea().setText("");
            
            JOptionPane.showMessageDialog(view, 
                "Bill deleted successfully!", 
                "Success", 
                JOptionPane.INFORMATION_MESSAGE);
            
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(view, 
                "Error deleting bill: " + e.getMessage(), 
                "Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

}
